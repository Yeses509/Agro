Drop real photos here (JPG). Any missing file falls back to the illustration, or is hidden.

Mega menu + product/partner blocks (use the same file for both):
  menu-tablets.jpg        4:3  (about 1200x1000)  Tablets & Capsules
  menu-syrups.jpg         4:3                      Syrups & Drops
  menu-injectables.jpg    4:3                      Injectables
  menu-creams.jpg         4:3                      Creams & Ointments
  card-distributors.jpg   3:4  (about 900x1250)   Distributors
  card-providers.jpg      3:4                      Healthcare organizations

Wide banners (21:8, about 2100x800):
  about-facility.jpg      Home + About
  research-lab.jpg        Research
  partners-logistics.jpg  Partners
  contact-office.jpg      Contact

News thumbnails (16:10, about 1200x750):
  news-1.jpg  news-2.jpg  news-3.jpg
