
(function(){
  var header = document.getElementById('header');
  var nav = document.getElementById('nav');
  var dd = document.getElementById('dd');
  var storyLink = document.getElementById('story-link');
  var triggers = Array.prototype.slice.call(nav.querySelectorAll('.trigger'));
  var order = ['discover','journeys','regions'];
  var panels = {
    discover: document.getElementById('p-discover'),
    journeys: document.getElementById('p-journeys'),
    regions: document.getElementById('p-regions')
  };
  var PAD = 20;
  var current = null;
  var closeTimer = null;

  function triggerFor(id){
    return triggers.filter(function(t){ return t.dataset.menu === id; })[0];
  }

  function place(id){
    var p = panels[id];
    var t = triggerFor(id).getBoundingClientRect();
    var hr = header.getBoundingClientRect();
    var w = p.offsetWidth, h = p.offsetHeight;
    var x = t.left - PAD;
    x = Math.max(hr.left + 12, Math.min(x, hr.right - w - 12));
    x -= (dd.offsetParent || header).getBoundingClientRect().left;
    dd.style.setProperty('--x', x + 'px');
    dd.style.setProperty('--w', w + 'px');
    dd.style.setProperty('--h', h + 'px');
  }

  function setExpanded(id){
    triggers.forEach(function(t){
      t.setAttribute('aria-expanded', t.dataset.menu === id ? 'true' : 'false');
    });
  }

  function open(id){
    clearTimeout(closeTimer);
    if (current === id) return;
    var p = panels[id];
    if (!current){
      dd.classList.add('instant','snap');
      order.forEach(function(k){
        panels[k].classList.add('snap');
        panels[k].removeAttribute('data-state');
      });
      place(id);
      void dd.offsetWidth;
      dd.classList.remove('snap');
      order.forEach(function(k){ panels[k].classList.remove('snap'); });
      dd.classList.add('open');
      requestAnimationFrame(function(){ dd.classList.remove('instant'); });
    } else {
      var dir = order.indexOf(id) > order.indexOf(current) ? 1 : -1;
      panels[current].setAttribute('data-state', dir > 0 ? 'exit-left' : 'exit-right');
      p.classList.add('snap');
      p.setAttribute('data-state', dir > 0 ? 'exit-right' : 'exit-left');
      void p.offsetWidth;
      p.classList.remove('snap');
      place(id);
    }
    p.setAttribute('data-state', 'active');
    setExpanded(id);
    current = id;
  }

  function close(){
    dd.classList.remove('open');
    if (current) panels[current].removeAttribute('data-state');
    setExpanded(null);
    current = null;
  }

  function scheduleClose(ms){
    clearTimeout(closeTimer);
    closeTimer = setTimeout(close, ms === undefined ? 140 : ms);
  }

  triggers.forEach(function(t){
    t.addEventListener('pointerenter', function(e){
      if (e.pointerType === 'mouse') open(t.dataset.menu);
    });
    t.addEventListener('click', function(){
      if (current === t.dataset.menu) close(); else open(t.dataset.menu);
    });
  });

  nav.querySelectorAll('.plain-link').forEach(function(l){ l.addEventListener('pointerenter', function(e){
    if (e.pointerType === 'mouse') scheduleClose(60);
  }); });
  nav.addEventListener('pointerenter', function(){ clearTimeout(closeTimer); });
  nav.addEventListener('pointerleave', function(e){
    if (e.pointerType === 'mouse') scheduleClose();
  });
  nav.addEventListener('focusout', function(e){
    if (!nav.contains(e.relatedTarget)) scheduleClose(0);
  });

  var menuBtn = document.getElementById('menu-btn');
  var sheet = document.getElementById('sheet');
  function setSheet(openIt){
    sheet.classList.toggle('open', openIt);
    menuBtn.setAttribute('aria-expanded', openIt ? 'true' : 'false');
  }
  menuBtn.addEventListener('click', function(){
    setSheet(!sheet.classList.contains('open'));
  });
  sheet.addEventListener('click', function(e){
    if (e.target.closest('a')) setSheet(false);
  });

  document.addEventListener('keydown', function(e){
    if (e.key !== 'Escape') return;
    if (current){
      var t = triggerFor(current);
      close();
      if (t) t.focus();
    }
    setSheet(false);
  });

  document.addEventListener('pointerdown', function(e){
    if (!nav.contains(e.target)) close();
  });

  window.addEventListener('resize', function(){
    if (current) place(current);
  });

  var items = Array.prototype.slice.call(document.querySelectorAll('.d-item'));
  var imgs = Array.prototype.slice.call(document.querySelectorAll('.d-media img'));
  function activate(item){
    var n = parseInt(item.dataset.img, 10);
    items.forEach(function(i){ i.classList.toggle('is-active', i === item); });
    imgs.forEach(function(im, idx){ im.classList.toggle('is-active', idx === n); });
  }
  items.forEach(function(item){
    item.addEventListener('pointerenter', function(){ activate(item); });
    item.addEventListener('focus', function(){ activate(item); });
  });
})();


(function(){
  var f = document.getElementById('enquiry');
  if (f) f.addEventListener('submit', function(e){
    e.preventDefault();
    document.getElementById('thanks').textContent = 'Thank you. We will be in touch shortly.';
    f.reset();
  });
  var els = document.querySelectorAll('[data-rv]');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!('IntersectionObserver' in window) || reduce) return;
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if (e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, {threshold:0.12});
  els.forEach(function(el,i){
    el.classList.add('rv');
    el.style.transitionDelay = (i % 4) * 70 + 'ms';
    io.observe(el);
  });
})();


(function(){
  var pines=document.getElementById('pines'), d='M-40 700V650', x=-40;
  while(x<1640){var h=40+((x*37)%26)+(x%3)*8, w=22;
    d+='L'+x+' 650L'+(x+w/2)+' '+(650-h)+'L'+(x+w)+' 650';x+=w+2;}
  if(pines)pines.setAttribute('d',d+'V700Z');
  var c=document.getElementById('snow'); if(!c)return; var g=c.getContext('2d'), f=[], W,H;
  function size(){W=c.width=c.offsetWidth;H=c.height=c.offsetHeight;}
  size();window.addEventListener('resize',size);
  for(var i=0;i<130;i++)f.push({x:Math.random(),y:Math.random(),r:Math.random()*2+0.6,v:Math.random()*0.5+0.25,p:Math.random()*6});
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  (function tick(t){
    g.clearRect(0,0,W,H);g.fillStyle='rgba(255,255,255,0.85)';
    f.forEach(function(s){
      s.y+=s.v/ (H/700*60);s.x+=Math.sin(t/1800+s.p)*0.0004+0.0001;
      if(s.y>1){s.y=-0.02;s.x=Math.random();}if(s.x>1)s.x=0;
      g.globalAlpha=0.35+s.r/4;g.beginPath();g.arc(s.x*W,s.y*H,s.r,0,6.283);g.fill();
    });
    requestAnimationFrame(tick);
  })(0);
})();


(function(){
  var NAVY='#052350',TEAL='#09abc6';
  function piece(cls,k,sx,sy,sr,vars,path,fill){
    return '<g class="s" style="--sx:'+sx+';--sy:'+sy+';--sr:'+sr+'"><g class="m" style="--k:'+k+'"><g class="p '+cls+'" style="'+vars+'"><path d="'+path+'" fill="'+fill+'"/></g></g></g>';
  }
  function mark(bub){
    var b='';
    if(bub){
      var cx=[470,500,525,490,545,512,478,538,505],r=[9,13,8,11,7,14,10,8,12];
      b='<g filter="url(#goo)"><ellipse cx="512" cy="668" rx="40" ry="12" fill="'+TEAL+'"/>';
      cx.forEach(function(x,i){b+='<circle class="b" cx="'+x+'" cy="656" r="'+r[i]+'" fill="'+TEAL+'" style="--d:'+(i*0.7).toFixed(1)+';--t:'+(4+i%3)+'s"/>';});
      b+='</g>';
    }
    return '<svg class="mark" viewBox="296 236 432 570" aria-hidden="true">'+
      piece('tl',-14,-120,-90,-25,'--fx:-160px;--fy:-240px;--fr:-50deg;--by:-14px','M315 253H437V508L315 406Z',TEAL)+
      piece('tr',22,140,-60,22,'--fx:180px;--fy:-200px;--fr:50deg;--by:14px;--dl:0.15','M587 253H710V406L587 508Z',TEAL)+
      piece('nv',8,0,110,0,'--fx:0px;--fy:320px;--fr:0deg;--by:6px;--dl:0.3','M315 406L437 508V610A75 75 0 0 0 587 610V508L710 406V595A198 198 0 0 1 315 595Z',NAVY)+
      b+'</svg>';
  }
  function flag(){
    var g='';
    for(var i=0;i<12;i++){var x=i*5.5;g+='<g class="sl" style="--i:'+i+'"><svg x="'+x+'" y="0" width="5.5" height="34" viewBox="'+x+' 0 5.5 34"><use href="#flagsym"/></svg></g>';}
    return '<svg class="flag" viewBox="0 0 66 34" aria-hidden="true">'+g+'</svg>';
  }
  function letters(t){
    return t.split('').map(function(c,i){return c===' '?'<span class="sp"></span>':'<span class="ch" style="--i:'+i+'">'+c+'</span>';}).join('');
  }
  function lockup(){
    return '<span class="lk-mark">'+mark(true)+'</span><i class="lk-bar"></i><span class="lk-txt"><b>'+letters('UTAH PHARMA')+'</b><span class="usa">USA</span>'+flag()+'</span>';
  }
  document.querySelectorAll('[data-lockup]').forEach(function(e){e.innerHTML=lockup();});
  document.querySelectorAll('[data-umark]').forEach(function(e){e.innerHTML=mark(false);});
  document.querySelectorAll('[data-bigmark]').forEach(function(e){e.innerHTML=mark(true);});
  document.querySelectorAll('[data-flag]').forEach(function(e){e.innerHTML=flag();});

  var root=document.documentElement,reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce)return;
  window.addEventListener('pointermove',function(e){
    root.style.setProperty('--mx',((e.clientX/innerWidth-0.5)*2).toFixed(3));
    root.style.setProperty('--my',((e.clientY/innerHeight-0.5)*2).toFixed(3));
  },{passive:true});
  document.addEventListener('click',function(e){
    var m=e.target.closest&&e.target.closest('.mark');
    if(m){m.classList.add('spin');setTimeout(function(){m.classList.remove('spin');},1000);}
  });
  var big=document.querySelector('[data-bigmark]'),tick=false;
  if(!big)return;
  function scroll(){
    tick=false;
    var r=big.getBoundingClientRect(),c=(r.top+r.height/2)/innerHeight;
    var sp=Math.min(1,Math.max(0,(Math.abs(c-0.5)-0.12)*2.2));
    big.style.setProperty('--sp',sp.toFixed(3));
  }
  window.addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(scroll);}},{passive:true});
  scroll();
})();

(function(){
  var bar=document.querySelector('.fchips'); if(!bar)return;
  bar.addEventListener('click',function(e){
    var b=e.target.closest('button'); if(!b)return;
    bar.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b);});
    var f=b.dataset.f;
    document.querySelectorAll('#arts .m-card').forEach(function(c){c.classList.toggle('hide',f!=='all'&&c.dataset.cat!==f);});
  });
})();

(function(){
  if(!window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  document.querySelectorAll('.hero-video').forEach(function(v){v.removeAttribute('autoplay');v.pause();});
})();
